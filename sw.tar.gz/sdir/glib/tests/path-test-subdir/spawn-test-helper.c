#include <stdio.h>

int main (void)
{
  fprintf (stderr, "this is spawn-test-helper from path-test-subdir\n");
  return 5;
}
